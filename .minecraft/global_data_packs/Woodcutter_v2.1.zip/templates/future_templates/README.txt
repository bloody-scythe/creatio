The stonecutter does not appear to support recipes that require more than 1 of the ingredient item. 
If this feature is added, the templates in this folder will work as intended.